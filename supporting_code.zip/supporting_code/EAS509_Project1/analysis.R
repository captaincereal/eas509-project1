# Run from the project folder, or source this file from report.qmd.
# Only the six spending variables enter the baseline fit. Region is not used.
if (!all(vapply(c("cluster", "mclust"), requireNamespace, logical(1), quietly = TRUE))) {
  stop("Required packages: cluster and mclust. Install them first, or run source('render.R').")
}

spend <- c("Fresh", "Milk", "Grocery", "Frozen", "Detergents_Paper", "Delicassen")
seed <- 50901L
B <- 30L
fraction <- 0.80
candidate_k <- 2:5
input_file <- file.path("data", "wholesale_customers_uci.csv")
if (!file.exists(input_file)) {
  stop("Cannot find the data. Open EAS509_Project1.Rproj, or set the working directory to the folder containing analysis.R and data/.")
}
if (unname(tools::md5sum(input_file)) != "a77e467b90b10ec157fef6de32feef05") {
  stop("The input differs from the bundled UCI CSV. Restore the original file, or revise the documented source and analysis deliberately.")
}
dir.create("results", showWarnings = FALSE)
raw <- read.csv(input_file, check.names = FALSE)
stopifnot(all(c(spend, "Channel", "Region") %in% names(raw)))
raw$source_row <- seq_len(nrow(raw))
raw$analysis_id <- sprintf("uci_%03d", raw$source_row)
stopifnot(!anyDuplicated(raw$analysis_id))

# Eligibility is set before any fit. Channel must be available for the
# declared matched-sample sensitivity. No outlier trimming is performed.
x_raw <- as.matrix(raw[spend])
stopifnot(is.numeric(x_raw))
valid_spend <- apply(is.finite(x_raw) & x_raw >= 0, 1, all)
valid_channel <- !is.na(raw$Channel) & raw$Channel %in% c(1, 2)
eligible <- valid_spend & valid_channel
dat <- raw[eligible, c("analysis_id", "source_row", spend, "Channel")]
rownames(dat) <- dat$analysis_id
stopifnot(nrow(dat) >= 20L)

audit <- data.frame(
  variable = c("analysis_id", spend, "Channel", "Region"),
  role = c("Local source-row label", rep("Baseline", 6), "Sensitivity only", "Protected; unused"),
  missing = c(0L, colSums(is.na(raw[spend])), sum(is.na(raw$Channel)), NA_integer_),
  minimum = c(NA_real_, vapply(raw[spend], min, na.rm = TRUE, FUN.VALUE = numeric(1)), NA_real_, NA_real_),
  maximum = c(NA_real_, vapply(raw[spend], max, na.rm = TRUE, FUN.VALUE = numeric(1)), NA_real_, NA_real_)
)
write.csv(audit, "results/data_audit.csv", row.names = FALSE, na = "")
ledger <- data.frame(
  variable = c(spend, "Channel", "analysis_id/source_row", "Region"),
  role = c(rep("Baseline feature", 6), "One declared sensitivity", "Identifier only", "Protected; unused"),
  encoding = c(rep("log1p; centered; divided by full-sample SD", 6),
               "Nominal mismatch indicator", "Original public-source row order", "Excluded"),
  weight = c(rep("One coordinate with variance 1", 6),
             "Add 2 for mismatch to squared baseline distance", "0", "0"),
  distance = c(rep("Euclidean", 6), "sqrt(baseline distance squared + 2 * mismatch)", "Excluded", "Excluded"),
  rationale = c(rep("Reduce skew and prevent large-scale spending categories from automatically dominating", 6),
                "Test whether channel information changes the purchasing-only partition", "Match records without influencing geometry", "No use in fitting, selection, or interpretation")
)
write.csv(ledger, "results/representation_ledger.csv", row.names = FALSE)
write.csv(data.frame(code = c(1, 2), meaning = c("Horeca: hotel, restaurant, cafe", "Retail"),
                     n = c(sum(raw$Channel == 1), sum(raw$Channel == 2))),
          "results/channel_levels.csv", row.names = FALSE)
write.csv(data.frame(stage = c("Raw", "Eligible", "Evaluated"),
                     n = c(nrow(raw), nrow(dat), nrow(dat))),
          "results/sample_audit.csv", row.names = FALSE)

log_spend <- log1p(as.matrix(dat[spend]))
centers <- colMeans(log_spend)
scales <- apply(log_spend, 2, sd)
stopifnot(all(is.finite(scales)), all(scales > 0))
z <- scale(log_spend, center = centers, scale = scales)
distance <- dist(z, method = "euclidean")
distance_matrix <- as.matrix(distance)
check_distance <- function(d) {
  m <- as.matrix(d)
  stopifnot(all(is.finite(m)), max(abs(m - t(m))) < 1e-10,
            all(abs(diag(m)) < 1e-10), all(m >= 0))
}
check_distance(distance)

fit_partition <- function(d, method, k) {
  if (method == "PAM") {
    fit <- cluster::pam(d, k = k, diss = TRUE, do.swap = TRUE, pamonce = 0)
    labels <- fit$clustering
  } else if (method == "Average linkage") {
    labels <- cutree(hclust(d, method = "average"), k = k)
  } else stop("Unknown grouping method")
  labels <- as.integer(labels)
  names(labels) <- attr(d, "Labels")
  labels
}

# ARI is an agreement statistic; no mixture model is fitted.
ari <- mclust::adjustedRandIndex

# Selection is defined before fitting: largest mean silhouette over the
# eight candidates; exact ties favor smaller k, then PAM. There is no
# post-hoc cluster-size exclusion or universal silhouette cutoff.
fits <- list()
candidate_rows <- list()
for (method in c("PAM", "Average linkage")) {
  for (k in candidate_k) {
    key <- paste(method, k, sep = "_")
    labels <- fit_partition(distance, method, k)
    si <- cluster::silhouette(labels, distance)
    sizes <- tabulate(labels, nbins = k)
    fits[[key]] <- labels
    candidate_rows[[key]] <- data.frame(
      method = method, k = k, silhouette = mean(si[, "sil_width"]),
      negative_pct = 100 * mean(si[, "sil_width"] < 0),
      min_group = min(sizes), max_group = max(sizes),
      sizes = paste(sizes, collapse = "/"), coverage = 1
    )
  }
}
candidates <- do.call(rbind, candidate_rows)
rownames(candidates) <- NULL
ranked <- order(-candidates$silhouette, candidates$k, match(candidates$method, c("PAM", "Average linkage")))
winner <- candidates[ranked[1], , drop = FALSE]
method <- winner$method
k <- winner$k
labels <- fits[[paste(method, k, sep = "_")]]

# Canonical display labels follow the median grocery spending. This
# renames groups after selection; it cannot change membership or ARI.
group_order <- order(tapply(dat$Grocery, labels, median), seq_len(k))
display_map <- setNames(seq_len(k), group_order)
labels <- unname(display_map[as.character(labels)])
names(labels) <- dat$analysis_id
sil <- cluster::silhouette(labels, distance)[, "sil_width"]
names(sil) <- dat$analysis_id

frozen <- list(
  source_file = input_file, source_md5 = unname(tools::md5sum(input_file)),
  source_kind = "Public UCI CSV; course ID mapping not verified",
  ids = dat$analysis_id, features = spend, transformation = "log1p",
  center = centers, scale = scales, distance = "Euclidean",
  method = method, k = k, candidate_k = candidate_k,
  selection_rule = "Maximum mean silhouette; exact ties favor smaller k, then PAM",
  pam_do_swap = TRUE, pamonce = 0L, linkage = "average",
  resampling = list(B = B, fraction = fraction, replace = FALSE,
                    seed = seed,
                    rng_kind = c("Mersenne-Twister", "Inversion", "Rejection"),
                    preprocessing = "Full-fit centers and SDs held fixed"),
  sensitivity = "Add Channel nominal mismatch penalty 2 to squared baseline distance; hold method and k fixed"
)
saveRDS(frozen, "results/frozen_specification.rds")
capture.output(dput(frozen), file = "results/frozen_specification.txt")
write.csv(candidates, "results/method_comparison.csv", row.names = FALSE)
write.csv(data.frame(
  method = c("PAM", "Average linkage"),
  representation = "Six log1p SD-standardized spending coordinates; Euclidean distance",
  concept = c("Groups around observed medoids", "Agglomeration by average between-group distance"),
  candidates = "k = 2, 3, 4, 5", diagnostic = "Mean silhouette and group sizes",
  rationale = c("Representative-account grouping", "A distinct hierarchical group concept on the same geometry")
), "results/method_representation.csv", row.names = FALSE)

profiles_for <- function(partition) {
  do.call(rbind, lapply(sort(unique(partition)), function(g) {
    take <- partition == g
    data.frame(group = g, n = sum(take), percent = 100 * mean(take),
               as.list(vapply(dat[take, spend, drop = FALSE], median, FUN.VALUE = numeric(1))),
               retail_pct = 100 * mean(dat$Channel[take] == 2),
               check.names = FALSE)
  }))
}
profile <- profiles_for(labels)
write.csv(profile, "results/group_profiles.csv", row.names = FALSE)

permutations <- function(v) {
  if (length(v) == 1L) return(matrix(v, nrow = 1L))
  do.call(rbind, lapply(seq_along(v), function(i) cbind(v[i], permutations(v[-i]))))
}
# At most five groups are considered: checking at most 5! = 120 possible
# label matchings is small enough to do directly without another package.
possible <- permutations(seq_len(k))
match_groups <- function(reference, alternative) {
  js <- matrix(NA_real_, k, k)
  for (g in seq_len(k)) for (h in seq_len(k)) {
    den <- sum(reference == g | alternative == h)
    js[g, h] <- if (!any(reference == g) || den == 0L) NA_real_ else sum(reference == g & alternative == h) / den
  }
  score <- apply(possible, 1, function(p) sum(js[cbind(seq_len(k), p)], na.rm = TRUE))
  mapping <- possible[which.max(score), ]
  remapped <- match(alternative, mapping)
  list(labels = remapped, jaccard = js[cbind(seq_len(k), mapping)], mapping = mapping)
}

# Exactly one sensitivity: add Channel as a nominal feature, without
# retuning the frozen method or k. With two nominal levels, a coordinate
# of 0 or sqrt(2) adds 2 to squared distance only when channels differ.
channel_coordinate <- sqrt(2) * as.integer(dat$Channel == 2)
alternative_distance <- dist(cbind(z, Channel = channel_coordinate))
check_distance(alternative_distance)
alternative_labels_raw <- fit_partition(alternative_distance, method, k)
matched_alternative <- match_groups(labels, alternative_labels_raw)
alternative_labels <- matched_alternative$labels
names(alternative_labels) <- dat$analysis_id
alternative_profile <- profiles_for(alternative_labels)
sensitivity_ari <- ari(labels, alternative_labels)
write.csv(data.frame(
  baseline = "Six log1p SD-standardized spend features; Euclidean distance",
  alternative = "Add Channel nominal mismatch penalty 2 to squared distance",
  reason = "Assess whether excluding business channel changes the purchasing-only story",
  method = method, k = k, n = nrow(dat),
  baseline_sizes = paste(profile$n, collapse = "/"),
  alternative_sizes = paste(alternative_profile$n, collapse = "/"),
  ari = sensitivity_ari, changed_accounts = sum(labels != alternative_labels),
  baseline_coverage = 1, alternative_coverage = 1,
  rare_group_fresh_median_baseline = profile$Fresh[1],
  rare_group_fresh_median_alternative = alternative_profile$Fresh[1]
), "results/sensitivity_comparison.csv", row.names = FALSE)
write.csv(alternative_profile, "results/sensitivity_profiles.csv", row.names = FALSE)
write.csv(data.frame(group = seq_len(k), jaccard = matched_alternative$jaccard),
          "results/sensitivity_jaccard.csv", row.names = FALSE)

# Independent 80% subsamples, with no replacement within each draw.
# Preprocessing, method, k, fitting rule, and distance remain frozen.
RNGkind("Mersenne-Twister", "Inversion", "Rejection")
set.seed(seed)
sample_n <- floor(fraction * nrow(dat))
stability <- vector("list", B)
sample_records <- vector("list", B)
group_records <- vector("list", B)
for (b in seq_len(B)) {
  rows <- sort(sample.int(nrow(dat), size = sample_n, replace = FALSE))
  ids <- dat$analysis_id[rows]
  d_sub <- as.dist(distance_matrix[rows, rows, drop = FALSE])
  subsample_labels <- fit_partition(d_sub, method, k)
  baseline_labels <- labels[ids]
  stopifnot(identical(names(baseline_labels), ids), identical(names(subsample_labels), ids))
  matched <- match_groups(baseline_labels, subsample_labels)
  stability[[b]] <- data.frame(run = b, n = sample_n,
                              ari = ari(baseline_labels, subsample_labels),
                              coverage = 1, fitted_groups = length(unique(subsample_labels)))
  sample_records[[b]] <- data.frame(run = b, analysis_id = ids,
                                  full_group = unname(baseline_labels),
                                  refit_group = unname(subsample_labels),
                                  matched_group = matched$labels,
                                  retained = unname(baseline_labels) == matched$labels)
  group_records[[b]] <- data.frame(
    run = b, group = seq_len(k), jaccard = matched$jaccard,
    full_sample_n = tabulate(baseline_labels, nbins = k),
    refit_n = tabulate(matched$labels, nbins = k),
    sampling_absent = tabulate(baseline_labels, nbins = k) == 0
  )
}
stability <- do.call(rbind, stability)
sample_records <- do.call(rbind, sample_records)
group_records <- do.call(rbind, group_records)
write.csv(stability, "results/resampling_stability.csv", row.names = FALSE)
write.csv(sample_records, "results/resample_memberships.csv", row.names = FALSE)
write.csv(group_records, "results/resampling_group_jaccard.csv", row.names = FALSE)
membership <- data.frame(
  analysis_id = dat$analysis_id, source_row = dat$source_row,
  group = unname(labels), sensitivity_group = unname(alternative_labels),
  silhouette = unname(sil)
)
write.csv(membership, "results/membership.csv", row.names = FALSE)

summaries <- list(
  n_raw = nrow(raw), n_eligible = nrow(dat), n_eval = nrow(dat),
  missing_spend = sum(is.na(x_raw)), invalid_spend = sum(!valid_spend),
  invalid_channel = sum(!valid_channel),
  duplicate_spend_rows = sum(duplicated(raw[spend])),
  method = method, k = k, silhouette = mean(sil),
  negative_n = sum(sil < 0), negative_pct = 100 * mean(sil < 0),
  silhouette_quantiles = quantile(sil, c(0, .25, .5, .75, 1)),
  group_silhouette = tapply(sil, labels, mean),
  comparison_ari = ari(fits[[paste("PAM", k, sep = "_")]], fits[[paste("Average linkage", k, sep = "_")]]),
  sensitivity_ari = sensitivity_ari,
  sensitivity_changed = sum(labels != alternative_labels),
  sensitivity_jaccard = matched_alternative$jaccard,
  stability_ari = quantile(stability$ari, c(0, .25, .5, .75, 1)),
  group_jaccard = tapply(group_records$jaccard, group_records$group, quantile, probs = c(0, .25, .5, .75, 1), na.rm = TRUE),
  perfect_runs = sum(abs(stability$ari - 1) < 1e-12),
  rare_group_sampling_absences = sum(group_records$sampling_absent[group_records$group == 1]),
  group_sizes = table(labels),
  min_group_resample_n = tapply(group_records$refit_n, group_records$group, min),
  max_group_resample_n = tapply(group_records$refit_n, group_records$group, max),
  sample_n = sample_n, seed = seed, B = B,
  source_md5 = frozen$source_md5
)
capture.output(dput(summaries), file = "results/summary.txt")
capture.output(sessionInfo(), file = "results/session_info.txt")
analysis_results <- list(summary = summaries, profile = profile, alternative_profile = alternative_profile,
                         candidates = candidates, stability = stability, group_stability = group_records,
                         memberships = membership, frozen = frozen)
saveRDS(analysis_results, "results/analysis_results.rds")
print(summaries)
print(candidates, digits = 4, row.names = FALSE)
print(profile, digits = 5, row.names = FALSE)
print(alternative_profile, digits = 5, row.names = FALSE)
