# Open EAS509_Project1.Rproj, then run source("render.R").
render_project <- function() {
  needed_files <- c("report.qmd", "analysis.R", "data/wholesale_customers_uci.csv")
  if (!all(file.exists(needed_files))) {
    stop("Open EAS509_Project1.Rproj first, or set the working directory to the project folder.",
         call. = FALSE)
  }
  root <- normalizePath(".", winslash = "/", mustWork = TRUE)
  lib <- file.path(root, ".R-library")
  dir.create(lib, showWarnings = FALSE)
  if (!dir.exists(lib)) stop("Cannot create the project R library: ", lib, call. = FALSE)

  candidates <- unname(Sys.which(c("quarto.exe", "quarto", "quarto.cmd")))
  if (.Platform$OS.type == "windows") {
    pandoc <- Sys.getenv("RSTUDIO_PANDOC")
    program_files <- Sys.getenv("ProgramFiles", "C:/Program Files")
    local_apps <- Sys.getenv("LOCALAPPDATA")
    candidates <- c(sub("\\.cmd$", ".exe", candidates, ignore.case = TRUE), candidates,
      if (nzchar(pandoc)) file.path(pandoc, "..", "quarto.exe"),
      file.path(program_files, "RStudio", "resources", "app", "bin", "quarto", "bin", "quarto.exe"),
      if (nzchar(local_apps)) file.path(local_apps, "Programs", "RStudio", "resources", "app", "bin", "quarto", "bin", "quarto.exe"))
  }
  candidates <- unique(candidates[nzchar(candidates) & file.exists(candidates)])
  if (.Platform$OS.type == "windows") candidates <- candidates[order(!grepl("\\.exe$", candidates, ignore.case = TRUE))]
  if (!length(candidates)) {
    stop("Quarto was not found. Install Quarto from https://quarto.org/docs/get-started/, ",
         "restart RStudio, and run source('render.R') again.", call. = FALSE)
  }
  quarto <- normalizePath(candidates[1], winslash = "/", mustWork = TRUE)

  old_libs <- .libPaths()
  on.exit(.libPaths(old_libs), add = TRUE)
  .libPaths(unique(c(lib, old_libs)))
  packages <- c("cluster", "mclust", "knitr", "rmarkdown")
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    message("Installing required R packages into ", lib)
    install.packages(missing, lib = lib, repos = "https://cloud.r-project.org")
  }
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    stop("R packages are still missing: ", paste(missing, collapse = ", "),
         ". Check the installation messages and internet access, then retry.", call. = FALSE)
  }

  vars <- c("R_LIBS_USER", "QUARTO_R")
  old_env <- Sys.getenv(vars, unset = NA_character_)
  on.exit({
    for (v in vars) {
      if (is.na(old_env[[v]])) Sys.unsetenv(v) else do.call(Sys.setenv, setNames(list(old_env[[v]]), v))
    }
  }, add = TRUE)
  Sys.setenv(R_LIBS_USER = paste(.libPaths(), collapse = .Platform$path.sep),
             QUARTO_R = R.home("bin"))
  message("Rendering report.qmd with ", quarto)
  status <- system2(quarto, c("render", "report.qmd", "--to", "typst"))
  if (status != 0L || !file.exists("report.pdf")) {
    stop("Rendering failed. Read the Quarto messages above; check packages, fonts, and the source files.",
         call. = FALSE)
  }
  message("Created ", file.path(root, "report.pdf"))
  invisible(file.path(root, "report.pdf"))
}

render_project()
