# Wholesale customer segmentation

EAS509 Project 1 · Hanu Varma Pinamaraju

## Data

The input contains 440 historical customer accounts from Cardoso's public UCI Wholesale customers dataset. The six spending columns are annual amounts in monetary units. Channel is nominal: 1 = Horeca and 2 = Retail. Region is excluded from the analysis.

The analysis uses the public CSV with source-order labels `uci_001` to `uci_440`. These labels are only for matching records. Correspondence to the course-provided file and its `customer_id` values has not been verified.

Source: Cardoso, M. (2013). *Wholesale customers*. UCI Machine Learning Repository. https://doi.org/10.24432/C5030X. License: CC BY 4.0.

The original CSV and download details are in `data/`. `source.json` labels both the CSV's SHA-256 and its MD5 explicitly; the MD5 is checked at startup to keep the analysis tied to the included input. These hashes refer to the unzipped CSV, not its source archive.

## Analysis

The baseline uses six log-transformed, standardized spending measures and Euclidean distance. PAM and average-linkage hierarchical clustering are compared at two through five groups. Both use the same accounts and distances, permitting a common descriptive silhouette comparison. The highest mean selects the result examined in detail; it does not establish useful customer types.

The Channel comparison adds `sqrt(2) * (Channel == 2)` as one coordinate. This increases squared distance by 2 for a channel mismatch and leaves same-channel distances unchanged. The selected method, number of groups, and spending transformation stay fixed.

Stability is assessed using 30 independent 80% subsamples without replacement, with seed 50901 and explicit random-number settings. Full-data scales are retained. Each comparison matches the same sampled accounts. ARI is calculated with `mclust::adjustedRandIndex()`. Group matching maximizes total Jaccard overlap over the possible label permutations.

Interpretation and the recommendation are in the report. The evidence tables contain the computed diagnostics, sizes, profiles, and memberships.

## Reproduction

Requirements: R, Quarto with Typst support, and the R packages `cluster`, `mclust`, `knitr`, and `rmarkdown`.

From the project directory:

```r
source("render.R")
```

The RStudio project file sets this directory when opened. The rendering script installs missing R packages from CRAN into `.R-library`, locates Quarto, and rebuilds `report.pdf`. A first run requires internet access if packages are missing. The report uses Times New Roman.

Analysis without PDF rendering:

```r
source("analysis.R")
analysis_results$candidates
analysis_results$profile
analysis_results$stability
```

In a configured terminal:

```text
quarto render report.qmd --to typst
```

The computations are repeated from the CSV on each render. The source set consists of `report.qmd`, `analysis.R`, and `data/`; all three are needed to rebuild the report. `session_info.txt` records the R process used by the most recent analysis or render.

## Project files

- `report.pdf`: three-page report.
- `report.qmd`: report text, tables, and figures.
- `analysis.R`: data preparation, grouping, sensitivity, and resampling.
- `render.R` and `EAS509_Project1.Rproj`: rendering and project setup.
- `data/`: input CSV and source information.
- `results/`: data audit, transformation details, candidate comparisons, selected settings, group profiles, and sampled-record labels.

The main evidence files are `method_comparison.csv`, `group_profiles.csv`, `sensitivity_comparison.csv`, and `resampling_stability.csv`. `resample_memberships.csv` contains the 10,560 sampled-record comparisons.

## References

- Cardoso, M. (2013). *Wholesale customers*. https://doi.org/10.24432/C5030X
- Maechler et al. (2025). *cluster*, version 2.1.8.1. https://CRAN.R-project.org/package=cluster
- R Core Team (2025). *R: A Language and Environment for Statistical Computing*. R Foundation, Vienna. Version used: 4.5.2. https://www.R-project.org/
- ARI function: https://mclust-org.github.io/mclust/reference/adjustedRandIndex.html
